from django.contrib import admin
from webmarks.upload.models import Upload

admin.site.register(Upload)

from django.apps import AppConfig


class NotesConfig(AppConfig):
    name = 'webmarks.notes'
    label = 'webmarks_notes'



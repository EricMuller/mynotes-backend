from django.apps import AppConfig


class BaseConfig(AppConfig):
    name = 'webmarks.base'
    label = 'webmarks_base'

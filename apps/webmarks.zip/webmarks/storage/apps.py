from django.apps import AppConfig


class StorageConfig(AppConfig):
    name = 'webmarks.storage'
    label = 'storage'
